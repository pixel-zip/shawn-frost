import { 
  Client, 
  Events, 
  GatewayIntentBits, 
  Collection, 
  REST, 
  Routes, 
  SlashCommandBuilder, 
  PermissionFlagsBits 
} from 'discord.js';

// Configuration du client avec tous les intents nécessaires
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildModeration
  ]
});

// Initialisation des collections
client.commands = new Collection();
client.warnings = new Collection();
client.levels = new Map();

// Configuration des serveurs
const serverConfigs = new Map();

// Configuration des niveaux
const LEVEL_CONFIG = {
  XP_PER_MESSAGE: 15,
  XP_PER_MINUTE_VOICE: 10,
  LEVEL_MULTIPLIER: 100
};

// Collection pour stocker les niveaux des utilisateurs
const userLevels = new Map();

// Système de niveaux
async function addXP(userId, guildId, xpToAdd) {
  const key = `${guildId}-${userId}`;
  if (!userLevels.has(key)) {
    userLevels.set(key, { xp: 0, level: 0 });
  }

  const userData = userLevels.get(key);
  userData.xp += xpToAdd;

  // Calculer le nouveau niveau
  const newLevel = Math.floor(userData.xp / LEVEL_CONFIG.LEVEL_MULTIPLIER);
  if (newLevel > userData.level) {
    userData.level = newLevel;
    return true; // Indique une montée de niveau
  }
  return false;
}

// Définition des commandes slash
const commands = [
  new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Répond avec la latence du bot'),

  new SlashCommandBuilder()
    .setName('info')
    .setDescription('Affiche les informations du serveur'),

  new SlashCommandBuilder()
    .setName('aide')
    .setDescription('Affiche la liste des commandes disponibles'),

  new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Expulse un membre')
    .addUserOption(option => 
      option.setName('utilisateur')
        .setDescription('L\'utilisateur à expulser')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('raison')
        .setDescription('La raison de l\'expulsion'))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

  new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Bannit un membre')
    .addUserOption(option => 
      option.setName('utilisateur')
        .setDescription('L\'utilisateur à bannir')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('raison')
        .setDescription('La raison du bannissement'))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Met un membre en timeout')
    .addUserOption(option => 
      option.setName('utilisateur')
        .setDescription('L\'utilisateur à mettre en timeout')
        .setRequired(true))
    .addIntegerOption(option =>
      option.setName('durée')
        .setDescription('Durée en minutes')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('raison')
        .setDescription('La raison du timeout'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  new SlashCommandBuilder()
    .setName('niveau')
    .setDescription('Affiche votre niveau ou celui d\'un utilisateur')
    .addUserOption(option =>
      option.setName('utilisateur')
        .setDescription('L\'utilisateur dont vous voulez voir le niveau')),

  new SlashCommandBuilder()
    .setName('classement')
    .setDescription('Affiche le classement des membres du serveur'),

  new SlashCommandBuilder()
    .setName('clear')
    .setDescription('Supprime un nombre spécifié de messages')
    .addIntegerOption(option =>
      option.setName('nombre')
        .setDescription('Nombre de messages à supprimer')
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(100))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  new SlashCommandBuilder()
    .setName('role')
    .setDescription('Ajoute ou retire un rôle à un membre')
    .addUserOption(option =>
      option.setName('utilisateur')
        .setDescription('L\'utilisateur à modifier')
        .setRequired(true))
    .addRoleOption(option =>
      option.setName('role')
        .setDescription('Le rôle à ajouter/retirer')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

  new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Avertir un membre')
    .addUserOption(option =>
      option.setName('utilisateur')
        .setDescription('L\'utilisateur à avertir')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('raison')
        .setDescription('La raison de l\'avertissement')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  // Nouvelles commandes de configuration
  new SlashCommandBuilder()
    .setName('config')
    .setDescription('Configure les paramètres du bot')
    .addSubcommand(subcommand =>
      subcommand
        .setName('welcome')
        .setDescription('Configure le message de bienvenue')
        .addChannelOption(option =>
          option.setName('channel')
            .setDescription('Le salon où envoyer les messages de bienvenue')
            .setRequired(true))
        .addStringOption(option =>
          option.setName('message')
            .setDescription('Le message de bienvenue (utilisez {user} pour mentionner le membre)')
            .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('autorole')
        .setDescription('Configure le rôle automatique')
        .addRoleOption(option =>
          option.setName('role')
            .setDescription('Le rôle à donner aux nouveaux membres')
            .setRequired(true)))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  new SlashCommandBuilder()
    .setName('salon')
    .setDescription('Gère les salons')
    .addSubcommand(subcommand =>
      subcommand
        .setName('create')
        .setDescription('Crée un nouveau salon')
        .addStringOption(option =>
          option.setName('nom')
            .setDescription('Le nom du salon')
            .setRequired(true))
        .addStringOption(option =>
          option.setName('type')
            .setDescription('Le type de salon')
            .setRequired(true)
            .addChoices(
              { name: 'Texte', value: 'text' },
              { name: 'Vocal', value: 'voice' },
              { name: 'Annonce', value: 'news' }
            )))
    .addSubcommand(subcommand =>
      subcommand
        .setName('delete')
        .setDescription('Supprime un salon')
        .addChannelOption(option =>
          option.setName('salon')
            .setDescription('Le salon à supprimer')
            .setRequired(true)))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
];

// Événement quand le bot est prêt
client.once(Events.ClientReady, async (readyClient) => {
  console.log(`Bot prêt ! Connecté en tant que ${readyClient.user.tag}`);

  try {
    // Enregistrer les commandes slash
    const rest = new REST().setToken(process.env.DISCORD_TOKEN);
    console.log('Début de l\'enregistrement des commandes slash...');

    await rest.put(
      Routes.applicationCommands(readyClient.user.id),
      { body: commands },
    );

    console.log('Commandes slash enregistrées avec succès !');
  } catch (error) {
    console.error('Erreur lors de l\'enregistrement des commandes:', error);
  }
});

// Gérer les interactions de commandes
client.on(Events.InteractionCreate, async interaction => {
  if (!interaction.isChatInputCommand()) return;

  const { commandName } = interaction;

  try {
    switch (commandName) {
      case 'ping':
        const sent = await interaction.reply({ content: 'Calcul de la latence...', fetchReply: true });
        await interaction.editReply(`🏓 Pong! Latence: ${sent.createdTimestamp - interaction.createdTimestamp}ms | Latence API: ${Math.round(client.ws.ping)}ms`);
        break;

      case 'info':
        const guild = interaction.guild;
        await interaction.reply({
          embeds: [{
            title: `ℹ️ Information sur ${guild.name}`,
            fields: [
              { name: '👥 Membres', value: `${guild.memberCount}`, inline: true },
              { name: '📅 Créé le', value: guild.createdAt.toLocaleDateString(), inline: true },
              { name: '👑 Propriétaire', value: `<@${guild.ownerId}>`, inline: true },
              { name: '🎭 Rôles', value: `${guild.roles.cache.size}`, inline: true },
              { name: '💬 Salons', value: `${guild.channels.cache.size}`, inline: true },
              { name: '🎨 Emojis', value: `${guild.emojis.cache.size}`, inline: true }
            ],
            thumbnail: { url: guild.iconURL() || null },
            color: 0x3498db
          }]
        });
        break;

      case 'aide':
        await interaction.reply({
          embeds: [{
            title: '📚 Liste des commandes',
            description: commands.map(cmd => `**/${cmd.name}** - ${cmd.description}`).join('\n'),
            color: 0x2ecc71
          }]
        });
        break;

      case 'kick':
        const kickUser = interaction.options.getUser('utilisateur');
        const kickReason = interaction.options.getString('raison') || 'Aucune raison fournie';
        const kickMember = await interaction.guild.members.fetch(kickUser.id);

        console.log(`Tentative d'expulsion de ${kickUser.tag} par ${interaction.user.tag}`);

        if (!kickMember.kickable) {
          console.log(`Impossible d'expulser ${kickUser.tag} - Permissions insuffisantes`);
          return interaction.reply({ content: '❌ Je ne peux pas expulser cet utilisateur.', ephemeral: true });
        }

        try {
          await kickMember.kick(kickReason);
          console.log(`${kickUser.tag} a été expulsé par ${interaction.user.tag}`);
          await interaction.reply({
            embeds: [{
              title: '👢 Membre expulsé',
              description: `**${kickUser.tag}** a été expulsé par ${interaction.user}.\nRaison: ${kickReason}`,
              color: 0xe74c3c
            }]
          });
        } catch (error) {
          console.error(`Erreur lors de l'expulsion de ${kickUser.tag}:`, error);
          await interaction.reply({ 
            content: '❌ Une erreur est survenue lors de l\'expulsion.', 
            ephemeral: true 
          });
        }
        break;

      case 'ban':
        const banUser = interaction.options.getUser('utilisateur');
        const banReason = interaction.options.getString('raison') || 'Aucune raison fournie';
        const banMember = await interaction.guild.members.fetch(banUser.id);

        console.log(`Tentative de bannissement de ${banUser.tag} par ${interaction.user.tag}`);

        if (!banMember.bannable) {
          console.log(`Impossible de bannir ${banUser.tag} - Permissions insuffisantes`);
          return interaction.reply({ content: '❌ Je ne peux pas bannir cet utilisateur.', ephemeral: true });
        }

        try {
          await banMember.ban({ reason: banReason });
          console.log(`${banUser.tag} a été banni par ${interaction.user.tag}`);
          await interaction.reply({
            embeds: [{
              title: '🔨 Membre banni',
              description: `**${banUser.tag}** a été banni par ${interaction.user}.\nRaison: ${banReason}`,
              color: 0xe74c3c
            }]
          });
        } catch (error) {
          console.error(`Erreur lors du bannissement de ${banUser.tag}:`, error);
          await interaction.reply({ 
            content: '❌ Une erreur est survenue lors du bannissement.', 
            ephemeral: true 
          });
        }
        break;

      case 'timeout':
        const timeoutUser = interaction.options.getUser('utilisateur');
        const timeoutDuration = interaction.options.getInteger('durée');
        const timeoutReason = interaction.options.getString('raison') || 'Aucune raison fournie';
        const timeoutMember = await interaction.guild.members.fetch(timeoutUser.id);

        console.log(`Tentative de timeout de ${timeoutUser.tag} par ${interaction.user.tag}`);

        if (!timeoutMember.moderatable) {
          console.log(`Impossible de mettre ${timeoutUser.tag} en timeout - Permissions insuffisantes`);
          return interaction.reply({ content: '❌ Je ne peux pas mettre cet utilisateur en timeout.', ephemeral: true });
        }

        try {
          await timeoutMember.timeout(timeoutDuration * 60 * 1000, timeoutReason);
          console.log(`${timeoutUser.tag} a été mis en timeout par ${interaction.user.tag}`);
          await interaction.reply({
            embeds: [{
              title: '⏰ Membre mis en timeout',
              description: `**${timeoutUser.tag}** a été mis en timeout pour ${timeoutDuration} minutes par ${interaction.user}.\nRaison: ${timeoutReason}`,
              color: 0xe74c3c
            }]
          });
        } catch (error) {
          console.error(`Erreur lors du timeout de ${timeoutUser.tag}:`, error);
          await interaction.reply({ 
            content: '❌ Une erreur est survenue lors du timeout.', 
            ephemeral: true 
          });
        }
        break;

      case 'config':
        const subcommand = interaction.options.getSubcommand();
        const guildConfig = serverConfigs.get(interaction.guildId) || {};

        if (subcommand === 'welcome') {
          const channel = interaction.options.getChannel('channel');
          const message = interaction.options.getString('message');

          guildConfig.welcome = { channel: channel.id, message };
          serverConfigs.set(interaction.guildId, guildConfig);

          await interaction.reply({
            embeds: [{
              title: '✅ Configuration des messages de bienvenue',
              description: `Les messages seront envoyés dans ${channel}\nMessage: ${message}`,
              color: 0x2ecc71
            }]
          });
        } else if (subcommand === 'autorole') {
          const role = interaction.options.getRole('role');

          guildConfig.autorole = role.id;
          serverConfigs.set(interaction.guildId, guildConfig);

          await interaction.reply({
            embeds: [{
              title: '✅ Configuration du rôle automatique',
              description: `Le rôle ${role} sera automatiquement donné aux nouveaux membres.`,
              color: 0x2ecc71
            }]
          });
        }
        break;

      case 'salon':
        const salonSubcommand = interaction.options.getSubcommand();

        if (salonSubcommand === 'create') {
          const name = interaction.options.getString('nom');
          const type = interaction.options.getString('type');

          const channel = await interaction.guild.channels.create({
            name,
            type: type === 'text' ? 0 : type === 'voice' ? 2 : 5
          });

          await interaction.reply({
            embeds: [{
              title: '✅ Salon créé',
              description: `Le salon ${channel} a été créé avec succès.`,
              color: 0x2ecc71
            }]
          });
        } else if (salonSubcommand === 'delete') {
          const channel = interaction.options.getChannel('salon');

          await channel.delete();
          await interaction.reply({
            embeds: [{
              title: '✅ Salon supprimé',
              description: `Le salon ${channel.name} a été supprimé avec succès.`,
              color: 0x2ecc71
            }]
          });
        }
        break;
      case 'niveau':
        const targetUser = interaction.options.getUser('utilisateur') || interaction.user;
        const userData = userLevels.get(`${interaction.guild.id}-${targetUser.id}`) || { xp: 0, level: 0 };

        await interaction.reply({
          embeds: [{
            title: `Niveau de ${targetUser.username}`,
            fields: [
              { name: 'Niveau', value: `${userData.level}`, inline: true },
              { name: 'XP', value: `${userData.xp}`, inline: true },
              { name: 'XP pour niveau suivant', value: `${(userData.level + 1) * LEVEL_CONFIG.LEVEL_MULTIPLIER - userData.xp}`, inline: true }
            ],
            thumbnail: { url: targetUser.displayAvatarURL() }
          }]
        });
        break;

      case 'classement':
        const guildUserLevels = Array.from(userLevels.entries())
          .filter(([key]) => key.startsWith(interaction.guild.id))
          .map(([key, data]) => ({
            userId: key.split('-')[1],
            ...data
          }))
          .sort((a, b) => b.xp - a.xp)
          .slice(0, 10);

        const leaderboardFields = await Promise.all(
          guildUserLevels.map(async (data, index) => {
            const user = await client.users.fetch(data.userId);
            return {
              name: `#${index + 1} ${user.username}`,
              value: `Niveau ${data.level} (${data.xp} XP)`
            };
          })
        );

        await interaction.reply({
          embeds: [{
            title: '🏆 Classement du serveur',
            fields: leaderboardFields,
            color: 0xffd700
          }]
        });
        break;

      case 'warn':
        const warnUser = interaction.options.getUser('utilisateur');
        const warnReason = interaction.options.getString('raison');

        if (!client.warnings.has(interaction.guild.id)) {
          client.warnings.set(interaction.guild.id, new Map());
        }

        const userWarnings = client.warnings.get(interaction.guild.id);
        if (!userWarnings.has(warnUser.id)) {
          userWarnings.set(warnUser.id, []);
        }

        userWarnings.get(warnUser.id).push({
          reason: warnReason,
          moderator: interaction.user.id,
          timestamp: new Date()
        });

        const warningCount = userWarnings.get(warnUser.id).length;

        await interaction.reply({
          embeds: [{
            title: '⚠️ Avertissement',
            description: `${warnUser} a reçu un avertissement.`,
            fields: [
              { name: 'Raison', value: warnReason },
              { name: 'Modérateur', value: `${interaction.user}` },
              { name: 'Total d\'avertissements', value: `${warningCount}` }
            ],
            color: 0xff9900,
            timestamp: new Date()
          }]
        });

        // Actions automatiques basées sur le nombre d'avertissements
        if (warningCount >= 3) {
          await interaction.followUp({
            content: `⚠️ ${warnUser} a atteint ${warningCount} avertissements. Actions recommandées : timeout, kick ou ban.`,
            ephemeral: true
          });
        }
        break;
    }
  } catch (error) {
    console.error(`Erreur lors de l'exécution de la commande ${commandName}:`, error);
    const errorMessage = 'Une erreur est survenue lors de l\'exécution de la commande.';
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp({ content: errorMessage, ephemeral: true });
    } else {
      await interaction.reply({ content: errorMessage, ephemeral: true });
    }
  }
});

// Gérer les nouveaux membres
client.on(Events.GuildMemberAdd, async member => {
  const guildConfig = serverConfigs.get(member.guild.id);
  if (!guildConfig) return;

  // Message de bienvenue
  if (guildConfig.welcome) {
    const channel = member.guild.channels.cache.get(guildConfig.welcome.channel);
    if (channel) {
      const message = guildConfig.welcome.message.replace('{user}', member.toString());
      await channel.send({
        embeds: [{
          title: '👋 Nouveau membre!',
          description: message,
          color: 0x2ecc71,
          thumbnail: { url: member.user.displayAvatarURL() }
        }]
      });
    }
  }

  // Rôle automatique
  if (guildConfig.autorole) {
    try {
      const role = member.guild.roles.cache.get(guildConfig.autorole);
      if (role) {
        await member.roles.add(role);
        console.log(`Rôle automatique ${role.name} ajouté à ${member.user.tag}`);
      }
    } catch (error) {
      console.error(`Erreur lors de l'ajout du rôle automatique pour ${member.user.tag}:`, error);
    }
  }
});

// Gérer les mentions du bot
client.on(Events.MessageCreate, async message => {
  // Ignorer les messages des bots et les messages privés
  if (message.author.bot || !message.guild) return;

  // Ajouter de l'XP pour le message
  const levelUp = await addXP(message.author.id, message.guild.id, LEVEL_CONFIG.XP_PER_MESSAGE);

  if (levelUp) {
    const userData = userLevels.get(`${message.guild.id}-${message.author.id}`);
    const levelUpChannel = message.guild.channels.cache.find(channel => 
      channel.name === 'niveau-up' || channel.name === 'levels'
    );

    if (levelUpChannel) {
      await levelUpChannel.send({
        embeds: [{
          title: '🎉 Nouveau niveau!',
          description: `${message.author} a atteint le niveau ${userData.level}!`,
          color: 0x00ff00
        }]
      });
    }
  }

  // Répondre aux mentions
  if (message.mentions.has(client.user)) {
    await message.reply('👋 Hey! Utilisez `/aide` pour voir la liste des commandes disponibles.');
  }
});

// Gérer les erreurs globales
client.on(Events.Error, error => {
  console.error('Erreur Discord.js:', error);
});

process.on('unhandledRejection', error => {
  console.error('Promesse non gérée:', error);
});

// Connexion du bot
console.log('Tentative de connexion du bot...');
client.login(process.env.DISCORD_TOKEN)
  .then(() => console.log('Bot connecté avec succès !'))
  .catch(error => {
    console.error('Erreur de connexion:', error);
    process.exit(1);
  });