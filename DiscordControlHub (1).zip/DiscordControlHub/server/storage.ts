import { BotConfig, Server, Command, InsertBotConfig, InsertServer, InsertCommand } from "@shared/schema";

export interface IStorage {
  // Bot Config
  getBotConfig(): Promise<BotConfig | undefined>;
  updateBotConfig(config: InsertBotConfig): Promise<BotConfig>;
  
  // Servers
  getServers(): Promise<Server[]>;
  getServer(id: string): Promise<Server | undefined>;
  upsertServer(server: InsertServer): Promise<Server>;
  removeServer(id: string): Promise<void>;
  
  // Commands
  getCommands(): Promise<Command[]>;
  getCommand(id: number): Promise<Command | undefined>;
  createCommand(command: InsertCommand): Promise<Command>;
  updateCommand(id: number, enabled: boolean): Promise<Command>;
}

export class MemStorage implements IStorage {
  private botConfig?: BotConfig;
  private servers: Map<string, Server>;
  private commands: Map<number, Command>;
  private commandId: number;

  constructor() {
    this.servers = new Map();
    this.commands = new Map();
    this.commandId = 1;
    
    // Add default commands
    const defaultCommands: InsertCommand[] = [
      { name: "ping", description: "Check bot latency", enabled: true },
      { name: "help", description: "Show available commands", enabled: true },
      { name: "status", description: "Show bot status", enabled: true }
    ];
    
    defaultCommands.forEach(cmd => this.createCommand(cmd));
  }

  async getBotConfig(): Promise<BotConfig | undefined> {
    return this.botConfig;
  }

  async updateBotConfig(config: InsertBotConfig): Promise<BotConfig> {
    this.botConfig = { id: 1, ...config };
    return this.botConfig;
  }

  async getServers(): Promise<Server[]> {
    return Array.from(this.servers.values());
  }

  async getServer(id: string): Promise<Server | undefined> {
    return this.servers.get(id);
  }

  async upsertServer(server: InsertServer): Promise<Server> {
    this.servers.set(server.id, server);
    return server;
  }

  async removeServer(id: string): Promise<void> {
    this.servers.delete(id);
  }

  async getCommands(): Promise<Command[]> {
    return Array.from(this.commands.values());
  }

  async getCommand(id: number): Promise<Command | undefined> {
    return this.commands.get(id);
  }

  async createCommand(command: InsertCommand): Promise<Command> {
    const id = this.commandId++;
    const newCommand = { ...command, id };
    this.commands.set(id, newCommand);
    return newCommand;
  }

  async updateCommand(id: number, enabled: boolean): Promise<Command> {
    const command = await this.getCommand(id);
    if (!command) throw new Error("Command not found");
    
    const updated = { ...command, enabled };
    this.commands.set(id, updated);
    return updated;
  }
}

export const storage = new MemStorage();
