import os
import discord
from discord import app_commands
from discord.ext import commands
import asyncio
from dotenv import load_dotenv
from datetime import datetime
import logging
import re
from collections import defaultdict, deque
from typing import Dict, Deque, Set, Tuple

# Configuration du logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

# Bot configuration
intents = discord.Intents.all()
bot = commands.Bot(command_prefix="!", intents=intents)

# Dictionnaires pour stocker les données
warnings = {}
levels = defaultdict(lambda: {"xp": 0, "level": 0, "voice_time": 0})
voice_sessions = {}
welcome_configs = {}
goodbye_configs = {}

# Configuration des niveaux
class LevelConfig:
    def __init__(self):
        self.xp_per_message = 15  # XP gagné par message
        self.xp_per_minute_voice = 10  # XP gagné par minute en vocal
        self.level_up_base = 100  # XP nécessaire pour le niveau 1
        self.level_up_multiplier = 1.5  # Multiplicateur pour chaque niveau

        # Rôles de niveau (ID du rôle : niveau requis)
        self.level_roles = {
            "Débutant": 5,
            "Intermédiaire": 10,
            "Expert": 20,
            "Maître": 30,
            "Légende": 50
        }

level_config = LevelConfig()

def calculate_xp_for_level(level: int) -> int:
    """Calcule l'XP nécessaire pour atteindre un niveau"""
    return int(level_config.level_up_base * (level_config.level_up_multiplier ** (level - 1)))

async def check_level_up(guild, member, old_level: int) -> None:
    """Vérifie si un membre a gagné un niveau et attribue les rôles"""
    current_xp = levels[member.id]["xp"]
    new_level = 0

    # Calculer le nouveau niveau
    while current_xp >= calculate_xp_for_level(new_level + 1):
        new_level += 1

    levels[member.id]["level"] = new_level

    # Si le niveau a augmenté
    if new_level > old_level:
        channel = discord.utils.get(guild.channels, name="level-up")
        if channel:
            embed = discord.Embed(
                title="🎉 Niveau supérieur!",
                description=f"{member.mention} a atteint le niveau {new_level}!",
                color=discord.Color.gold()
            )
            await channel.send(embed=embed)

        # Vérifier et attribuer les rôles de niveau
        for role_name, required_level in level_config.level_roles.items():
            if new_level >= required_level:
                role = discord.utils.get(guild.roles, name=role_name)
                if role and role not in member.roles:
                    await member.add_roles(role)
                    if channel:
                        await channel.send(f"🎭 {member.mention} a obtenu le rôle {role.name}!")

@bot.event
async def on_message(message):
    if message.author.bot:
        return

    # Auto-modération
    action = await check_message(message)
    if action:
        await handle_automod_action(message, action)

    # Ajouter de l'XP pour le message
    old_level = levels[message.author.id]["level"]
    levels[message.author.id]["xp"] += level_config.xp_per_message
    await check_level_up(message.guild, message.author, old_level)

    await bot.process_commands(message)

@bot.event
async def on_voice_state_update(member, before, after):
    """Gestion des sessions vocales"""
    if member.bot:
        return

    # Membre rejoint un canal vocal
    if before.channel is None and after.channel is not None:
        voice_sessions[member.id] = datetime.now()

    # Membre quitte un canal vocal
    elif before.channel is not None and after.channel is None and member.id in voice_sessions:
        start_time = voice_sessions.pop(member.id)
        duration = (datetime.now() - start_time).total_seconds() / 60  # En minutes

        # Ajouter l'XP pour le temps passé en vocal
        old_level = levels[member.id]["level"]
        xp_gained = int(duration * level_config.xp_per_minute_voice)
        levels[member.id]["xp"] += xp_gained
        levels[member.id]["voice_time"] += duration

        await check_level_up(member.guild, member, old_level)

@bot.tree.command(name="rank", description="Afficher votre niveau et XP")
async def rank(interaction: discord.Interaction):
    """Affiche les statistiques de niveau d'un membre"""
    member = interaction.user
    user_data = levels[member.id]
    current_level = user_data["level"]
    current_xp = user_data["xp"]
    voice_time = user_data["voice_time"]

    # Calculer l'XP nécessaire pour le prochain niveau
    next_level_xp = calculate_xp_for_level(current_level + 1)

    embed = discord.Embed(
        title=f"Statistiques de {member.name}",
        color=discord.Color.blue()
    )

    embed.add_field(name="Niveau", value=str(current_level))
    embed.add_field(name="XP Total", value=str(current_xp))
    embed.add_field(name="Prochain niveau", value=f"{current_xp}/{next_level_xp} XP")
    embed.add_field(name="Temps en vocal", value=f"{int(voice_time)} minutes")

    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="leaderboard", description="Afficher le classement des membres")
async def leaderboard(interaction: discord.Interaction):
    """Affiche le classement des membres par niveau et XP"""
    sorted_users = sorted(levels.items(), key=lambda x: (x[1]["level"], x[1]["xp"]), reverse=True)

    embed = discord.Embed(
        title="🏆 Classement du serveur",
        description="Top 10 des membres les plus actifs",
        color=discord.Color.gold()
    )

    for i, (user_id, data) in enumerate(sorted_users[:10], 1):
        member = interaction.guild.get_member(user_id)
        if member:
            embed.add_field(
                name=f"{i}. {member.name}",
                value=f"Niveau {data['level']} - {data['xp']} XP",
                inline=False
            )

    await interaction.response.send_message(embed=embed)

# Configuration de l'auto-modération
class AutoModerationConfig:
    def __init__(self):
        self.spam_interval = 5  # Intervalle en secondes
        self.spam_threshold = 5  # Nombre de messages maximum dans l'intervalle
        self.banned_words = {
            "gros_mots": ["mot1", "mot2", "mot3"],  # À personnaliser
            "discrimination": ["mot4", "mot5", "mot6"]  # À personnaliser
        }
        self.caps_threshold = 0.7  # Pourcentage maximum de majuscules
        self.message_history: Dict[int, Deque[Tuple[str, datetime]]] = defaultdict(lambda: deque(maxlen=10))
        self.repeat_threshold = 3  # Nombre de messages similaires maximum

auto_mod = AutoModerationConfig()

@bot.event
async def on_ready():
    logger.info(f'Bot connecté en tant que {bot.user}')
    try:
        logger.info("Début de la synchronisation des commandes...")
        synced = await bot.tree.sync()
        logger.info(f"Synchronisation réussie! {len(synced)} commande(s) synchronisée(s)")
    except Exception as e:
        logger.error(f"Erreur lors de la synchronisation des commandes: {e}")
    logger.info("Bot prêt à l'utilisation")

async def check_message(message) -> str:
    """
    Vérifie si un message enfreint les règles de modération
    Retourne le type d'infraction ou None
    """
    content = message.content.lower()
    author_id = message.author.id

    # 1. Vérification du spam
    now = datetime.now()
    auto_mod.message_history[author_id].append((content, now))
    recent_messages = [msg for msg, time in auto_mod.message_history[author_id]
                      if (now - time).total_seconds() <= auto_mod.spam_interval]

    if len(recent_messages) >= auto_mod.spam_threshold:
        return "spam"

    # 2. Vérification des mots interdits
    for category, words in auto_mod.banned_words.items():
        if any(word in content for word in words):
            return f"banned_word_{category}"

    # 3. Vérification des MAJUSCULES
    if len(message.content) > 10:
        caps_ratio = sum(1 for c in message.content if c.isupper()) / len(message.content)
        if caps_ratio > auto_mod.caps_threshold:
            return "excessive_caps"

    # 4. Vérification des messages répétés
    recent_content = [msg for msg, _ in auto_mod.message_history[author_id]]
    if len(recent_content) >= 3:
        if recent_content.count(content) >= auto_mod.repeat_threshold:
            return "repeat"

    return None

async def handle_automod_action(message, violation_type):
    """Gère les actions automatiques de modération"""
    action_taken = None
    reason = f"Auto-modération: {violation_type}"

    if violation_type == "spam":
        await message.delete()
        action_taken = "message supprimé (spam)"
        # Mute temporaire si spam persistant
        if len(auto_mod.message_history[message.author.id]) >= auto_mod.spam_threshold * 2:
            await mute(message.guild, message.author, 300, "Spam excessif")
            action_taken = "utilisateur muté (spam persistant)"

    elif violation_type.startswith("banned_word"):
        await message.delete()
        category = violation_type.split('_')[2]
        action_taken = f"message supprimé (langage inapproprié - {category})"

        # Ajouter un avertissement
        await warn(message.guild, message.author, f"Utilisation de langage inapproprié ({category})")

    elif violation_type == "excessive_caps":
        await message.delete()
        action_taken = "message supprimé (trop de majuscules)"
        await message.channel.send(f"{message.author.mention}, évitez d'utiliser trop de majuscules.")

    elif violation_type == "repeat":
        await message.delete()
        action_taken = "message supprimé (messages répétés)"
        await message.channel.send(f"{message.author.mention}, évitez de répéter les mêmes messages.")

    if action_taken:
        await log_moderation_action(message.guild, "auto-mod", message.author, bot.user, f"{action_taken} - {reason}")

@bot.tree.command(name="automod_config", description="Configurer l'auto-modération")
@app_commands.checks.has_permissions(administrator=True)
async def automod_config(interaction: discord.Interaction, spam_interval: int = None, spam_threshold: int = None):
    """Configure les paramètres d'auto-modération"""
    if spam_interval is not None:
        auto_mod.spam_interval = spam_interval
    if spam_threshold is not None:
        auto_mod.spam_threshold = spam_threshold

    embed = discord.Embed(
        title="Configuration de l'auto-modération",
        description="Paramètres actuels:",
        color=discord.Color.blue()
    )
    embed.add_field(name="Intervalle de spam", value=f"{auto_mod.spam_interval} secondes")
    embed.add_field(name="Seuil de spam", value=f"{auto_mod.spam_threshold} messages")
    await interaction.response.send_message(embed=embed)

@bot.event
async def on_member_join(member):
    """Événement déclenché quand un membre rejoint le serveur"""
    if member.guild.id in welcome_configs:
        channel_id = welcome_configs[member.guild.id]['channel_id']
        channel = member.guild.get_channel(channel_id)
        if channel:
            embed = discord.Embed(
                title="👋 Nouveau membre!",
                description=f"Bienvenue {member.mention} sur {member.guild.name}! 🎉",
                color=discord.Color.green()
            )
            embed.set_thumbnail(url=member.avatar.url if member.avatar else member.default_avatar.url)
            embed.add_field(name="Membre n°", value=str(len(member.guild.members)))
            embed.set_footer(text=f"Rejoint le {datetime.now().strftime('%d/%m/%Y à %H:%M')}")
            await channel.send(embed=embed)

@bot.tree.command(name="warn", description="Avertir un membre")
@app_commands.checks.has_permissions(kick_members=True)
async def warn(interaction: discord.Interaction, member: discord.Member, reason: str = "Aucune raison fournie"):
    """Avertir un membre"""
    if member.guild.id not in warnings:
        warnings[member.guild.id] = {}

    if member.id not in warnings[member.guild.id]:
        warnings[member.guild.id][member.id] = []

    warnings[member.guild.id][member.id].append({
        'reason': reason,
        'timestamp': datetime.now(),
        'moderator': interaction.user.id
    })

    warning_count = len(warnings[member.guild.id][member.id])

    embed = discord.Embed(
        title="⚠️ Avertissement",
        description=f"{member.mention} a reçu un avertissement.",
        color=discord.Color.orange()
    )
    embed.add_field(name="Raison", value=reason)
    embed.add_field(name="Nombre d'avertissements", value=str(warning_count))
    await interaction.response.send_message(embed=embed)

    # Log l'avertissement
    await log_moderation_action(interaction.guild, "warn", member, interaction.user, reason)

    # Actions automatiques basées sur le nombre d'avertissements
    if warning_count == 3:
        await interaction.channel.send(f"⚠️ {member.mention} a atteint 3 avertissements. Action recommandée: kick ou ban.")

@bot.tree.command(name="warnings", description="Voir les avertissements d'un membre")
@app_commands.checks.has_permissions(kick_members=True)
async def check_warnings(interaction: discord.Interaction, member: discord.Member):
    """Vérifier les avertissements d'un membre"""
    if member.guild.id not in warnings or member.id not in warnings[member.guild.id]:
        await interaction.response.send_message(f"{member.mention} n'a aucun avertissement.")
        return

    user_warnings = warnings[member.guild.id][member.id]
    embed = discord.Embed(
        title=f"Avertissements de {member.name}",
        description=f"Nombre total: {len(user_warnings)}",
        color=discord.Color.orange()
    )

    for i, warning in enumerate(user_warnings, 1):
        moderator = interaction.guild.get_member(warning['moderator'])
        embed.add_field(
            name=f"Avertissement {i}",
            value=f"Raison: {warning['reason']}\nPar: {moderator.mention}\nDate: {warning['timestamp'].strftime('%d/%m/%Y %H:%M')}",
            inline=False
        )

    await interaction.response.send_message(embed=embed)

async def log_moderation_action(guild, action, target, moderator, reason):
    """Enregistrer une action de modération dans les logs"""
    log_channel = discord.utils.get(guild.channels, name='mod-logs')
    if log_channel:
        embed = discord.Embed(
            title=f"Action de modération: {action.upper()}",
            description=f"Une action de modération a été effectuée.",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        embed.add_field(name="Cible", value=f"{target.mention} ({target.id})" if target else "N/A")
        embed.add_field(name="Modérateur", value=f"{moderator.mention} ({moderator.id})")
        embed.add_field(name="Raison", value=reason, inline=False)
        await log_channel.send(embed=embed)

@bot.tree.command(name="kick", description="Expulser un membre du serveur")
@app_commands.checks.has_permissions(kick_members=True)
async def kick(interaction: discord.Interaction, member: discord.Member, reason: str = "Aucune raison fournie"):
    """Kick un membre du serveur"""
    try:
        await member.kick(reason=reason)
        await interaction.response.send_message(f'{member.mention} a été kické. Raison: {reason}')
        await log_moderation_action(interaction.guild, "kick", member, interaction.user, reason)
    except discord.Forbidden:
        await interaction.response.send_message("Je n'ai pas la permission de kicker ce membre.")

@bot.tree.command(name="ban", description="Bannir un membre du serveur")
@app_commands.checks.has_permissions(ban_members=True)
async def ban(interaction: discord.Interaction, member: discord.Member, reason: str = "Aucune raison fournie"):
    """Ban un membre du serveur"""
    try:
        await member.ban(reason=reason)
        await interaction.response.send_message(f'{member.mention} a été banni. Raison: {reason}')
        await log_moderation_action(interaction.guild, "ban", member, interaction.user, reason)
    except discord.Forbidden:
        await interaction.response.send_message("Je n'ai pas la permission de bannir ce membre.")

@bot.tree.command(name="unban", description="Débannir un membre")
@app_commands.checks.has_permissions(ban_members=True)
async def unban(interaction: discord.Interaction, member_name: str):
    """Unban un membre du serveur"""
    try:
        banned_users = await interaction.guild.bans()
        member_name, member_discriminator = member_name.split('#') if '#' in member_name else (member_name, None)

        for ban_entry in banned_users:
            user = ban_entry.user
            if user.name == member_name:
                if member_discriminator is None or user.discriminator == member_discriminator:
                    await interaction.guild.unban(user)
                    await interaction.response.send_message(f'{user.mention} a été débanni.')
                    await log_moderation_action(interaction.guild, "unban", user, interaction.user, "Débanissement manuel")
                    return
        await interaction.response.send_message("Aucun utilisateur trouvé avec ce nom.")
    except discord.Forbidden:
        await interaction.response.send_message("Je n'ai pas la permission de débannir des membres.")

@bot.tree.command(name="clear", description="Supprimer un nombre spécifié de messages")
@app_commands.checks.has_permissions(manage_messages=True)
async def clear(interaction: discord.Interaction, amount: int):
    """Supprime un nombre spécifié de messages"""
    try:
        if amount <= 0:
            await interaction.response.send_message("Veuillez spécifier un nombre positif de messages à supprimer.")
            return
        await interaction.response.defer()
        deleted = await interaction.channel.purge(limit=amount)
        await interaction.followup.send(f'{len(deleted)} messages ont été supprimés.', delete_after=3)
        await log_moderation_action(interaction.guild, "clear", None, interaction.user, f"{len(deleted)} messages supprimés")
    except discord.Forbidden:
        await interaction.response.send_message("Je n'ai pas la permission de supprimer les messages.")

@bot.tree.command(name="mute", description="Rendre muet un membre temporairement")
@app_commands.checks.has_permissions(manage_roles=True)
async def mute(interaction: discord.Interaction, member: discord.Member, duration: int, reason: str = "Aucune raison fournie"):
    """Mute un membre pour une durée spécifiée (en secondes)"""
    try:
        mute_role = discord.utils.get(interaction.guild.roles, name="Muted")
        if not mute_role:
            mute_role = await interaction.guild.create_role(name="Muted", reason="Rôle de mute")
            for channel in interaction.guild.channels:
                await channel.set_permissions(mute_role,
                                               send_messages=False,
                                               speak=False,
                                               add_reactions=False)

        await member.add_roles(mute_role, reason=reason)
        await interaction.response.send_message(f'{member.mention} a été muté pour {duration} secondes. Raison: {reason}')
        await log_moderation_action(interaction.guild, "mute", member, interaction.user, reason)

        await asyncio.sleep(duration)
        if mute_role in member.roles:  # Check if still muted
            await member.remove_roles(mute_role)
            await interaction.channel.send(f'{member.mention} a été démuté.')
            await log_moderation_action(interaction.guild, "unmute", member, bot.user, "Dé-mute automatique")

    except discord.Forbidden:
        await interaction.response.send_message("Je n'ai pas la permission de gérer les rôles.")

# Error handling for app commands
@kick.error
@ban.error
@unban.error
@clear.error
@mute.error
@warn.error
@check_warnings.error
async def app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.MissingPermissions):
        await interaction.response.send_message("❌ Vous n'avez pas la permission d'utiliser cette commande.")
    elif isinstance(error, app_commands.CommandOnCooldown):
        await interaction.response.send_message(f"❌ Cette commande est en cooldown. Réessayez dans {error.retry_after:.2f} secondes.")
    else:
        await interaction.response.send_message(f"❌ Une erreur est survenue: {str(error)}")

@bot.tree.command(name="xp_config", description="Configurer les paramètres d'XP")
@app_commands.checks.has_permissions(administrator=True)
async def xp_config(interaction: discord.Interaction, xp_message: int = None, xp_vocal: int = None):
    """Configure les paramètres d'XP"""
    try:
        logger.info(f"Modification des paramètres XP demandée par {interaction.user} (ID: {interaction.user.id})")
        logger.info(f"Valeurs actuelles - XP message: {level_config.xp_per_message}, XP vocal: {level_config.xp_per_minute_voice}")

        if xp_message is not None:
            if xp_message < 0:
                await interaction.response.send_message("❌ L'XP par message ne peut pas être négatif.")
                return
            logger.info(f"Modification de l'XP par message: {level_config.xp_per_message} -> {xp_message}")
            level_config.xp_per_message = xp_message

        if xp_vocal is not None:
            if xp_vocal < 0:
                await interaction.response.send_message("❌ L'XP par minute en vocal ne peut pas être négatif.")
                return
            logger.info(f"Modification de l'XP vocal: {level_config.xp_per_minute_voice} -> {xp_vocal}")
            level_config.xp_per_minute_voice = xp_vocal

        embed = discord.Embed(
            title="⚙️ Configuration de l'XP",
            description="Paramètres actuels:",
            color=discord.Color.blue()
        )
        embed.add_field(name="XP par message", value=f"{level_config.xp_per_message} XP")
        embed.add_field(name="XP par minute en vocal", value=f"{level_config.xp_per_minute_voice} XP")
        embed.set_footer(text="Utilisez /xp_config xp_message:nombre xp_vocal:nombre pour modifier ces valeurs")

        await interaction.response.send_message(embed=embed)
        logger.info("Configuration XP mise à jour avec succès")

    except Exception as e:
        logger.error(f"Erreur lors de la configuration XP: {str(e)}")
        await interaction.response.send_message("❌ Une erreur est survenue lors de la modification des paramètres XP.")


@bot.tree.command(name="welcome_config", description="Configurer le message de bienvenue")
@app_commands.checks.has_permissions(administrator=True)
async def welcome_config(interaction: discord.Interaction, channel: discord.TextChannel = None, message: str = None):
    """Configure le salon et le message de bienvenue"""
    try:
        logger.info(f"Configuration du message de bienvenue par {interaction.user} (ID: {interaction.user.id})")

        if channel is None:
            # Afficher la configuration actuelle
            if interaction.guild.id in welcome_configs:
                config = welcome_configs[interaction.guild.id]
                channel = interaction.guild.get_channel(config['channel_id'])
                embed = discord.Embed(
                    title="📝 Configuration actuelle des messages de bienvenue",
                    color=discord.Color.blue()
                )
                embed.add_field(name="Salon", value=channel.mention if channel else "Non configuré")
                if 'message' in config:
                    embed.add_field(name="Message", value=config['message'])
                await interaction.response.send_message(embed=embed)
            else:
                await interaction.response.send_message("❌ Aucune configuration de bienvenue n'est définie.")
            return

        # Sauvegarder la nouvelle configuration
        welcome_configs[interaction.guild.id] = {
            'channel_id': channel.id,
            'message': message if message else f"Bienvenue {member.mention} sur {member.guild.name}! 🎉"
        }

        embed = discord.Embed(
            title="✅ Configuration des messages de bienvenue mise à jour",
            description=f"Les messages de bienvenue seront envoyés dans {channel.mention}",
            color=discord.Color.green()
        )
        if message:
            embed.add_field(name="Message", value=message)
        await interaction.response.send_message(embed=embed)
        logger.info(f"Configuration de bienvenue mise à jour pour le serveur {interaction.guild.id}")

    except Exception as e:
        logger.error(f"Erreur lors de la configuration du message de bienvenue: {str(e)}")
        await interaction.response.send_message("❌ Une erreur est survenue lors de la configuration.")

@bot.tree.command(name="goodbye_config", description="Configurer le message d'au revoir")
@app_commands.checks.has_permissions(administrator=True)
async def goodbye_config(interaction: discord.Interaction, channel: discord.TextChannel = None, message: str = None):
    """Configure le salon et le message d'au revoir"""
    try:
        logger.info(f"Configuration du message d'au revoir par {interaction.user} (ID: {interaction.user.id})")

        if channel is None:
            # Afficher la configuration actuelle
            if interaction.guild.id in goodbye_configs:
                config = goodbye_configs[interaction.guild.id]
                channel = interaction.guild.get_channel(config['channel_id'])
                embed = discord.Embed(
                    title="📝 Configuration actuelle des messages d'au revoir",
                    color=discord.Color.blue()
                )
                embed.add_field(name="Salon", value=channel.mention if channel else "Non configuré")
                if 'message' in config:
                    embed.add_field(name="Message", value=config['message'])
                await interaction.response.send_message(embed=embed)
            else:
                await interaction.response.send_message("❌ Aucune configuration d'au revoir n'est définie.")
            return

        # Sauvegarder la nouvelle configuration
        goodbye_configs[interaction.guild.id] = {
            'channel_id': channel.id,
            'message': message if message else f"{member.name} nous a quittés... 😢"
        }

        embed = discord.Embed(
            title="✅ Configuration des messages d'au revoir mise à jour",
            description=f"Les messages d'au revoir seront envoyés dans {channel.mention}",
            color=discord.Color.green()
        )
        if message:
            embed.add_field(name="Message", value=message)
        await interaction.response.send_message(embed=embed)
        logger.info(f"Configuration d'au revoir mise à jour pour le serveur {interaction.guild.id}")

    except Exception as e:
        logger.error(f"Erreur lors de la configuration du message d'au revoir: {str(e)}")
        await interaction.response.send_message("❌ Une erreur est survenue lors de la configuration.")

@bot.event
async def on_member_remove(member):
    """Événement déclenché quand un membre quitte le serveur"""
    if member.guild.id in goodbye_configs:
        channel_id = goodbye_configs[member.guild.id]['channel_id']
        channel = member.guild.get_channel(channel_id)
        if channel:
            message = goodbye_configs[member.guild.id].get('message', f"{member.name} nous a quittés... 😢")
            embed = discord.Embed(
                title="👋 Au revoir!",
                description=message,
                color=discord.Color.orange()
            )
            embed.set_thumbnail(url=member.avatar.url if member.avatar else member.default_avatar.url)
            embed.set_footer(text=f"Parti le {datetime.now().strftime('%d/%m/%Y à %H:%M')}")
            await channel.send(embed=embed)

# Run the bot
TOKEN = os.getenv('DISCORD_TOKEN')
if TOKEN is None:
    logger.error("Erreur: Aucun token trouvé dans les variables d'environnement")
else:
    logger.info("Démarrage du bot...")
    bot.run(TOKEN)