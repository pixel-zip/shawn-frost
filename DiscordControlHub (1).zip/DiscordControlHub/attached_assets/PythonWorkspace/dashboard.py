import os
from flask import Flask, render_template, redirect, url_for, session, request
from requests_oauthlib import OAuth2Session
from dotenv import load_dotenv
from functools import wraps
import logging

# Configuration du logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "your-secret-key")

# Configuration OAuth2 Discord
DISCORD_CLIENT_ID = os.getenv('DISCORD_CLIENT_ID')
DISCORD_CLIENT_SECRET = os.getenv('DISCORD_CLIENT_SECRET')
DISCORD_REDIRECT_URI = os.getenv('DISCORD_REDIRECT_URI', 'https://discordbot-dashboard.' + os.getenv('REPL_OWNER', '') + '.repl.co/callback')
DISCORD_BOT_TOKEN = os.getenv('DISCORD_TOKEN')

# Log l'URL de redirection au démarrage
logger.info(f"URL de redirection configurée: {DISCORD_REDIRECT_URI}")

DISCORD_AUTH_BASE_URL = "https://discord.com/api/oauth2/authorize"
DISCORD_TOKEN_URL = "https://discord.com/api/oauth2/token"
DISCORD_API_BASE_URL = "https://discord.com/api"

def token_updater(token):
    session['oauth2_token'] = token

def make_session(token=None, state=None):
    return OAuth2Session(
        client_id=DISCORD_CLIENT_ID,
        token=token,
        state=state,
        redirect_uri=DISCORD_REDIRECT_URI,
        scope=['identify', 'guilds']
    )

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'oauth2_token' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def index():
    logger.info("Accès à la page d'accueil")

    # Vérifier si les secrets sont configurés
    if not DISCORD_CLIENT_ID or not DISCORD_CLIENT_SECRET:
        error_message = "Configuration OAuth2 manquante. Veuillez configurer DISCORD_CLIENT_ID et DISCORD_CLIENT_SECRET."
        logger.error(error_message)
        return render_template('index.html', error=error_message)

    if 'oauth2_token' in session:
        return redirect(url_for('dashboard'))
    return render_template('index.html', redirect_uri=DISCORD_REDIRECT_URI)

@app.route('/login')
def login():
    logger.info("Tentative de connexion")
    if not DISCORD_CLIENT_ID or not DISCORD_CLIENT_SECRET:
        logger.error("Tentative de connexion sans configuration OAuth2")
        return redirect(url_for('index'))

    discord = make_session()
    authorization_url, state = discord.authorization_url(DISCORD_AUTH_BASE_URL)
    session['oauth2_state'] = state
    logger.info(f"Redirection vers l'autorisation Discord: {authorization_url}")
    return redirect(authorization_url)

@app.route('/callback')
def callback():
    logger.info("Callback OAuth2 reçu")
    if request.values.get('error'):
        error = request.values['error']
        logger.error(f"Erreur OAuth2: {error}")
        return render_template('index.html', error=f"Erreur d'authentification: {error}")

    try:
        discord = make_session(state=session.get('oauth2_state'))
        token = discord.fetch_token(
            DISCORD_TOKEN_URL,
            client_secret=DISCORD_CLIENT_SECRET,
            authorization_response=request.url
        )
        session['oauth2_token'] = token
        logger.info("Authentification réussie")
        return redirect(url_for('dashboard'))
    except Exception as e:
        logger.error(f"Erreur lors de l'authentification: {str(e)}")
        return render_template('index.html', error=f"Erreur lors de l'authentification: {str(e)}")

@app.route('/dashboard')
@login_required
def dashboard():
    try:
        discord = make_session(token=session.get('oauth2_token'))
        user = discord.get(f'{DISCORD_API_BASE_URL}/users/@me').json()
        guilds = discord.get(f'{DISCORD_API_BASE_URL}/users/@me/guilds').json()

        logger.info(f"Accès au dashboard pour l'utilisateur: {user.get('username')}")
        return render_template(
            'dashboard.html',
            user=user,
            guilds=[g for g in guilds if (int(g['permissions']) & 0x8) == 0x8]  # Filtrer les serveurs où l'utilisateur est admin
        )
    except Exception as e:
        logger.error(f"Erreur dans le dashboard: {str(e)}")
        return render_template('index.html', error=f"Erreur lors du chargement du dashboard: {str(e)}")

@app.route('/logout')
def logout():
    logger.info("Déconnexion de l'utilisateur")
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    # ALWAYS serve the app on port 5000
    logger.info("Démarrage du serveur dashboard sur le port 5000")
    logger.info(f"URL de l'application: https://discordbot-dashboard.{os.getenv('REPL_OWNER', '')}.repl.co")
    app.run(host='0.0.0.0', port=5000, debug=True)