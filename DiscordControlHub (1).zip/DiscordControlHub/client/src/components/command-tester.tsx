import { useState } from "react";
import { useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardHeader, CardContent, CardFooter } from "@/components/ui/card";
import { Command } from "@shared/schema";

interface CommandTesterProps {
  command: Command;
}

export function CommandTester({ command }: CommandTesterProps) {
  const [result, setResult] = useState<string>();
  const { register, handleSubmit } = useForm();

  const onTest = async (data: any) => {
    const ws = new WebSocket(`ws://${window.location.host}`);
    ws.onmessage = (event) => {
      const response = JSON.parse(event.data);
      if (response.type === "COMMAND_RESULT") {
        setResult(response.success ? "Command executed successfully!" : "Command failed");
      }
    };

    ws.onopen = () => {
      ws.send(JSON.stringify({
        type: "TEST_COMMAND",
        command: command.name,
        args: data.args
      }));
    };
  };

  return (
    <Card>
      <CardHeader>
        <h3 className="font-semibold">{command.name}</h3>
        <p className="text-sm text-muted-foreground">{command.description}</p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit(onTest)}>
          <Input {...register("args")} placeholder="Command arguments" />
        </form>
      </CardContent>
      <CardFooter className="flex justify-between items-center">
        <Button onClick={handleSubmit(onTest)} disabled={!command.enabled}>
          Test Command
        </Button>
        {result && (
          <span className="text-sm text-muted-foreground">{result}</span>
        )}
      </CardFooter>
    </Card>
  );
}
