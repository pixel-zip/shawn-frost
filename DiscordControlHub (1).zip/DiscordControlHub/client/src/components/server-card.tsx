import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { Server } from "@shared/schema";
import { Users } from "lucide-react";

interface ServerCardProps {
  server: Server;
}

export function ServerCard({ server }: ServerCardProps) {
  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center gap-2">
          {server.icon && (
            <img 
              src={server.icon} 
              alt={server.name} 
              className="w-8 h-8 rounded-full"
            />
          )}
          <h3 className="font-semibold">{server.name}</h3>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-2 text-muted-foreground">
          <Users size={16} />
          <span>{server.memberCount} members</span>
        </div>
        <div className="text-sm text-muted-foreground mt-2">
          Joined {new Date(server.joined).toLocaleDateString()}
        </div>
      </CardContent>
    </Card>
  );
}
